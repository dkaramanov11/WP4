package mk.ukim.finki.wp.lab.web.controller;

import jakarta.servlet.http.HttpSession;
import mk.ukim.finki.wp.lab.model.Album;
import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;
import mk.ukim.finki.wp.lab.service.ArtistService;
import mk.ukim.finki.wp.lab.service.SongService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.thymeleaf.spring6.SpringTemplateEngine;

import java.util.List;
import java.util.Map;

@Controller
public class ArtistController {
    private final ArtistService artistService;
    private final SongService songService;

    public ArtistController(ArtistService artistService, SongService songService) {
        this.artistService = artistService;
        this.songService = songService;
    }

    @GetMapping("/artist")
    public String getArtists(Model model) {
        List<Artist> listedArtists = artistService.listArtists();
        model.addAttribute("listedArtists", listedArtists);
        return "artistsList";
    }

    @PostMapping("/artist")
    public String postArtist(@RequestParam(required = false) String trackId,
                             Map<String, Object> model) {
        List<Artist> listedArtists = artistService.listArtists();
        model.put("trackId", trackId);
        model.put("listedArtists", listedArtists);
        return "artistsList"; // Refers to the "artistList.html" template
    }

}
